import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:async';
import 'dart:convert';
import 'package:gradient_app_bar/gradient_app_bar.dart';
import 'package:getflutter/getflutter.dart';

class ContentTheory extends StatefulWidget {
  final String language;
  final String topic;
  ContentTheory({Key key, @required this.language, @required this.topic})
      : super(key: key);

  @override
  _ContentTheoryState createState() =>
      _ContentTheoryState(language: language, topic: topic);
}

class _ContentTheoryState extends State<ContentTheory> {
  final String language;
  final String topic;
  String imageurl;
  final String url = "http://192.168.1.3:5000/getContent/";
  List data;
  List image;
  Future<String> getSWData() async {
    var res = await http.get(Uri.encodeFull(url + language + "/" + topic),
        headers: {"Accept": "application/json"});
    setState(() {
      var resBody = json.decode(res.body);
      data = resBody; //['result'];
    });
    debugPrint('json data: $data');
    return 'success';
  }

  Future<String> getImage() async {
    var res = await http.get(
        Uri.encodeFull(url + language + "/" + topic + "/code"),
        headers: {"Accept": "application/json"});
    setState(() {
      var resBody = json.decode(res.body);
      image = resBody; //['result'];
    });
    debugPrint('image url $image');
    if (image[0] == null) {
      image.add("https://googleflutter.com/sample_image.jpg");
    }
    return 'success';
  }

  @override
  void initState() {
    super.initState();
    this.getSWData();
    this.getImage();
    this.imageurl = "http://192.168.1.3:5000/getContent/" +
        language +
        "/" +
        topic +
        "/code";
  }

  _ContentTheoryState({Key key, @required this.language, @required this.topic});
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        theme: ThemeData.dark(),
        home: Scaffold(
          appBar: AppBar(
            bottom: TabBar(
              tabs: [
                Tab(icon: Icon(Icons.book)),
                Tab(icon: Icon(Icons.computer)),
              ],
            ),
            title: Center(child: Text(topic)),
          ),
          body: TabBarView(children: [
            ListView.builder(
              itemCount: data == null ? 0 : data.length,
              itemBuilder: (BuildContext context, int index) {
                return Container(
                  child: Center(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: <Widget>[
                        //Card(child: Text(data[index]['id']),),
                        Container(
                          width: 1000,
                          height: 1000,
                          child: InkWell(
                            child:
                                /*Card(
                              child: Center(child: Text(data[index])),
                            )*/
                                //child: Text.rich(data[index]),
                                GFCard(
                              boxFit: BoxFit.cover,
                              //imageOverlay: AssetImage('your asset image'),
                              title: GFListTile(
                                //avatar: GFAvatar(),
                                //title: Text(topic,style: TextStyle(fontStyle:FontStyle.italic,fontSize: 25,fontWeight: FontWeight.bold)),
                                subTitle: Text(data[index],style: TextStyle(fontSize: 20,fontStyle: FontStyle.italic,),),
                              ),
                            ),
                            onTap: () => {print(data[index])},
                          ),
                        )
                      ],
                    ),
                  ),
                );
              },
            ),
            Text('image[0]')
            //Image.network(image[0]),
            // Image.network(imageurl)
          ]),
        ),
      ),
    );
  }
}
