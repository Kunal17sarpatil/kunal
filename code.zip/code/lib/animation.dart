//import 'dart:ffi';

import 'package:flutter/material.dart';
import 'package:gradient_app_bar/gradient_app_bar.dart';
import 'ContentList.dart';
import 'package:getflutter/getflutter.dart';

/*void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: MyHomePage(),
    );
  }
}*/

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        theme: ThemeData.dark(),
        debugShowCheckedModeBanner: false,
          home: Scaffold(
          appBar:/* GradientAppBar(
            title: Center(child: Text('Languages')),
            backgroundColorStart: Colors.cyan,
            backgroundColorEnd: Colors.indigo,
          )*/AppBar(
            title: Center(child: Text("Languages")),
            
          ),
          body: Container(
            child: Column(
              children: <Widget>[
                Center(
                  child: Container(
                    child: InkWell(
                      child: Padding(
                        padding: const EdgeInsets.only(top: 80, left: 25),
                        child: Container(
                          width: 340,
                          height: 140,
                          child: GFButton(
                            onPressed: () {
                              Navigator.push(context,
                                  MaterialPageRoute(builder: (context) {
                                return (ContentList(
                                  text1: "cpp",
                                ));
                              }));
                            },
                            text: "C++",
                            textStyle: TextStyle(fontSize: 40),
                            color: Colors.deepPurple[200],
                            shape: GFButtonShape.pills,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                Padding(padding: const EdgeInsets.all(15)),
                Container(
                  child: InkWell(
                    child: Padding(
                      padding: const EdgeInsets.only(top: 20, left: 25),
                      child: Container(
                        width: 340,
                        height: 140,
                        child: GFButton(
                          onPressed: () {
                            Navigator.push(context,
                                MaterialPageRoute(builder: (context) {
                              return (ContentList(
                                text1: "java",
                              ));
                            }));
                          },
                          text: "Java",
                          textStyle: TextStyle(fontSize: 35),
                          color: Colors.teal[200],
                          shape: GFButtonShape.pills,
                        ),
                      ),
                    ),
                  ),
                ),
                Padding(padding: const EdgeInsets.all(15)),
                Container(
                  child: InkWell(
                    child: Padding(
                      padding: const EdgeInsets.only(top: 20, left: 25),
                      child: Container(
                        width: 340,
                        height: 140,
                        child: GFButton(
                          onPressed: () {
                            Navigator.push(context,
                                MaterialPageRoute(builder: (context) {
                              return (ContentList(
                                text1: "python",
                              ));
                            }));
                          },
                          text: "Python",
                          textStyle: TextStyle(fontSize: 28),
                          color: Colors.red[200],
                          shape: GFButtonShape.pills,
                        ),
                      ),
                    ),
                  ),
                )
              ],
            ),
          )),
    );
  }
}
