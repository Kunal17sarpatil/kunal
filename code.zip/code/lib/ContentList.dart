import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:async';
import 'dart:convert';
import 'package:gradient_app_bar/gradient_app_bar.dart';
import 'package:getflutter/getflutter.dart';

import 'package:prog_appv1/ContentTheory.dart';

class ContentList extends StatefulWidget {
  final String text1;
  ContentList({Key key, @required this.text1}) : super(key: key);

  @override
  _ContentListState createState() => _ContentListState(text2: text1);
}

class _ContentListState extends State<ContentList> {
  final String text2;
  final String url = "http://192.168.1.3:5000/getContentList/";
  List data;
  Future<String> getSWData() async {
    var res = await http.get(Uri.encodeFull(url + text2),
        headers: {"Accept": "application/json"});
    setState(() {
      var resBody = json.decode(res.body);
      data = resBody; //['result'];
    });
    debugPrint('json data: $data');
    return 'success';
  }

  @override
  void initState() {
    super.initState();
    this.getSWData();
  }

  _ContentListState({Key key, @required this.text2});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(),
      home: Scaffold(
        appBar: AppBar(
          title: Center(child:Text(text2,),),
        ),
        body: Container(
          child: ListView.builder(
            itemCount: data == null ? 0 : data.length,
            itemBuilder: (BuildContext context, int index) {
              return Container(
                child: Center(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: <Widget>[
                      //Card(child: Text(data[index]['id']),),
                      Container(
                        width: 100,
                        height: 80,
                        child: InkWell(
                          child: Card(
                            child: GFListTile(
                                titleText: data[index],
                                color: Colors.white,
                                icon: Icon(Icons.keyboard_arrow_right,color: Colors.green,)),
                          ),
                          onTap: () => {
                            print(data[index]),
                            Navigator.push(context,
                                MaterialPageRoute(builder: (context) {
                              return ContentTheory(
                                  language: text2, topic: data[index]);
                            }))
                          },
                        ),
                      )
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}
