no = int(input("Enter No = "))
for n in range(no,0,-1):
    if(n%2!=0):
        print(n,end=" ")
print()
