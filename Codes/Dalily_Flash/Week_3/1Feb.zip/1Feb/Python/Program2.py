no = int(input("Enter No = "))
for n in range(no,-1,-1):
    if(n%2==0):
        print(n,end=" ")
print()
