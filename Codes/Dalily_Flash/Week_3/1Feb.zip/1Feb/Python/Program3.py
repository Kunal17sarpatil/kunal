hrs = int(input("Enter hours = "))
sec = hrs*3600
print("Seconds = ",sec)
