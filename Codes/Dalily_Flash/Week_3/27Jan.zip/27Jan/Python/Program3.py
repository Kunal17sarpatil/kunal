dist = int(input("Enter Distance = "))
time = int(input("Enter Time = "))
velocity = dist/time;
print("The velocity of a particle roaming in space is",velocity,"m/s")
