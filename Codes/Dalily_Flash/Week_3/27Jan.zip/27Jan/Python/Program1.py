no1 = int(input("Enter No1 = "))
no2 = int(input("Enter No2 = "))

for no in range(no1,no2+1):
    if(no%2==0):
        print(no,end=" ")
print()
