no1 = int(input("Enter No1 = "))
no2 = int(input("Enterr No2 = "))

if(no1<no2):
    print("The Minimum no. amongst",no1,"and",no2,"is",no1)
else:
    print("The Minimum no. amongst",no1,"and",no2,"is",no2)

