i = int(input("Enter Current(I) = "))
r = int(input("Enter resistance(R) = "))
v = i*r
print("Voltage V = ",v)
