for row in range(65,70):
    for no in range(70,row,-1):
        print(chr(row),end=" ")
    print();
