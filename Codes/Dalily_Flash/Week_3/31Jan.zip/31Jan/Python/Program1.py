lim = int(input("Enter Limit = "))
no = int(input("Enter No = "))
sum=1
for n in range(1,lim+1):
    print(sum,end=" ")
    sum = sum+no
print()
