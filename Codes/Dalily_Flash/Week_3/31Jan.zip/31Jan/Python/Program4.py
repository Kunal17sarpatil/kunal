no=7
for row in range(1,5):
    no1=no
    for no2 in range(row):
        print(no1,end=" ")
        no1=no1-1
    print()
    no=no-1
