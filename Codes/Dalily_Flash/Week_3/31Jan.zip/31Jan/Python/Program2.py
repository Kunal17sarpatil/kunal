dollar = int(input("Enter Dollars = "))
print("Rupees = ",(dollar*71.54))
