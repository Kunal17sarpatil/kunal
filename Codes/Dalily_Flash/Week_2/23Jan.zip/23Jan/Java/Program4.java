class Pattern4 {

	public static void main(String[] argg) {
	
		for(int row=1;row<=4;row++) {
		
			for(int star=1;star<=row;star++) {
			
				System.out.print("* ");
			}

			System.out.println();
		}
	}
}
