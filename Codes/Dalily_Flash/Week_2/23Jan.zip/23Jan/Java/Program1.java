class Pattern1 {

	public static void main(String[] args) {
	
		for(int row=1;row<=4;row++) {
		
			for(int no=1;no<=row;no++) {
			
				System.out.print(row+" ");
			}

			System.out.println();
		}
	}
}
