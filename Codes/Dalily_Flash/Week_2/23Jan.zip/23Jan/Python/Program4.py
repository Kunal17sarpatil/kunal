for row in range(1,5):
    for star in range(0,row):
        print("* ",end="")
    print()
