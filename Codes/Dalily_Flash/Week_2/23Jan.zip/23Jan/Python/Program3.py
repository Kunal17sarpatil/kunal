temp=0
for row in range(1,5):
    for no in range(0,row):
        temp = temp +1
        print(temp,end=" ")
    print()
